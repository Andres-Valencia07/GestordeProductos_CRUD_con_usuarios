package com.mycompany.gestordeproductos_crud;
 
public class Nivel4_02_DeclararMostrar {
    public static void main(String[] args) {
        Producto[] productos = new Producto[3];
        productos[0] = new Producto("Teclado", 50000, 10);
        productos[1] = new Producto("Mouse", 20000, 15);
        productos[2] = new Producto("Monitor", 450000, 5);
 
        for (Producto p : productos) {
            System.out.println(p);
        }
    } 
}
