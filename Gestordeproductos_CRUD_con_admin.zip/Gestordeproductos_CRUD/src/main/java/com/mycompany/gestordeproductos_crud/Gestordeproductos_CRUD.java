package com.mycompany.gestordeproductos_crud;

import java.util.Scanner;

public class Gestordeproductos_CRUD {
    static String[] nombres = new String[5];
    static double[] precios = new double[5];
    static int contador = 0;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean salirCompleto = false;

        do {
            int rol;

            do {
                System.out.println("\n--- Bienvenido al sistema ---");
                System.out.println("Seleccione su rol:");
                System.out.println("1. Administrador");
                System.out.println("2. Usuario");
                System.out.println("3. Salir");
                System.out.print("Opción: ");
                rol = sc.nextInt();
                sc.nextLine();

                if (rol != 1 && rol != 2 && rol != 3) {
                    System.out.println("Rol inválido, intente de nuevo.");
                }

            } while (rol != 1 && rol != 2 && rol != 3);

            if (rol == 3) {
                salirCompleto = true;
                continue;
            }

            int opcion;

            do {
                if (rol == 1) {
                    System.out.println("\n--- Menu Administrador ---");
                    System.out.println("1. Agregar (create)");
                    System.out.println("2. Listar");
                    System.out.println("3. Buscar producto");
                    System.out.println("4. Actualizar");
                    System.out.println("5. Eliminar producto");
                    System.out.println("0. Salir");
                } else if (rol == 2) {
                    System.out.println("\n--- Menu Usuario ---");
                    System.out.println("2. Listar");
                    System.out.println("3. Buscar producto");
                    System.out.println("0. Salir");
                }

                opcion = sc.nextInt();
                sc.nextLine();

                if (rol == 1) {
                    switch (opcion) {
                        case 1 -> {
                            System.out.println("Nombre del producto: ");
                            String nombre = sc.nextLine();
                            System.out.println("precio del producto: ");
                            double precio = sc.nextDouble();
                            agregar(nombre, precio);
                        }
                        case 2 -> {
                            Listar();
                        }
                        case 3 -> {
                            System.out.print("Nombre a buscar: ");
                            String nombre = sc.nextLine();
                            int idx = buscar(nombre);
                            System.out.println(idx == -1 ? "No encontrado." : "Encontrado en posición " + idx);
                        }
                        case 4 -> {
                            System.out.print("Nombre a actualizar: ");
                            String nombre = sc.nextLine();
                            System.out.print("Nuevo precio: ");
                            double nuevo = sc.nextDouble();
                            actualizarPrecio(nombre, nuevo);
                        }
                        case 5 -> {
                            System.out.print("Nombre a eliminar: ");
                            String nombre = sc.nextLine();
                            eliminar(nombre);
                        }
                        case 0 -> {
                            if (preguntarSalida(sc)) {
                                salirCompleto = true;
                            }
                        }
                        default -> System.out.println("Opción inválida.");
                    }
                } else if (rol == 2) {
                    switch (opcion) {
                        case 2 -> {
                            Listar();
                        }
                        case 3 -> {
                            System.out.print("Nombre a buscar: ");
                            String nombre = sc.nextLine();
                            int idx = buscar(nombre);
                            System.out.println(idx == -1 ? "No encontrado." : "Encontrado en posición " + idx);
                        }
                        case 0 -> {
                            if (preguntarSalida(sc)) {
                                salirCompleto = true;
                            }
                        }
                        default -> System.out.println("Opción inválida para su rol.");
                    }
                }

            } while (opcion != 0);

        } while (!salirCompleto);

        System.out.println("Sistema cerrado. ¡Hasta luego!");
        sc.close();
    }

    static boolean preguntarSalida(Scanner sc) {
        int op;
        do {
            System.out.println("\n¿Qué desea hacer?");
            System.out.println("1. Volver al menú principal");
            System.out.println("2. Cerrar el sistema");
            System.out.print("Opción: ");
            op = sc.nextInt();
            sc.nextLine();

            if (op != 1 && op != 2) {
                System.out.println("Opción inválida, intente de nuevo.");
            }
        } while (op != 1 && op != 2);

        return op == 2;
    }

    static boolean agregar(String nombre, double precio) {
        if (contador >= nombres.length) {
            System.out.println("No hay espacio en el vector para almacenar");
            return false;
        }
        nombres[contador] = nombre;
        precios[contador] = precio;
        contador++;

        return true;
    }

    static void Listar() {
        if (contador == 0) {
            System.out.println("No hay productos registrados");
        }

        for (int i = 0; i < contador; i++) {
            System.out.println(i + " " + nombres[i] + " - $ " + precios[i]);
        }
    }

    static int buscar(String nombre) {
        for (int i = 0; i < contador; i++) {
            if (nombres[i].equalsIgnoreCase(nombre)) {
                return i;
            }
        }
        return -1;
    }

    static boolean actualizarPrecio(String nombre, double nuevoPrecio) {
        int indice = buscar(nombre);
        if (indice == -1) {
            System.out.println("Producto no encontrado.");
            return false;
        }
        precios[indice] = nuevoPrecio;
        System.out.println("Precio actualizado con éxito.");
        return true;
    }

    static boolean eliminar(String nombre) {
        int indice = buscar(nombre);
        if (indice == -1) {
            System.out.println("Producto no encontrado.");
            return false;
        }

        for (int i = indice; i < contador - 1; i++) {
            nombres[i] = nombres[i + 1];
            precios[i] = precios[i + 1];
        }

        nombres[contador - 1] = null;
        precios[contador - 1] = 0.0;

        contador--;
        System.out.println("Producto eliminado con éxito.");
        return true;
    }
}