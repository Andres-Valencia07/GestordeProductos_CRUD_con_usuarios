/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestordeproductos_crud;

/**
 *
 * @author ESTUDIANTES
 */
public class Producto {
    String nombre;
    double precio;
    int cantidad;
    
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
        
    @Override
    public String toString() {
        return nombre + " | $" + precio + " | Cantidad: " + cantidad;
    }
}
